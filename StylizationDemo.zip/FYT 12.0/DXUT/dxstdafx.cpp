//--------------------------------------------------------------------------------------
// File: DxStdAfx.cpp
//
// Desc: Precompiled headers for DXUT and DirectX SDK samples
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------
#include "dxstdafx.h"



